package com.example.myapplication

class books(
    var BookName: String = "",
    var BookAuthor: String = "",
    var Price: String = "",
    var id :String="",
  //  var img:String="",
    var LaunchYear: String = ""
)
