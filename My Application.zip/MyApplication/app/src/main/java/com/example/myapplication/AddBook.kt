package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import kotlinx.android.synthetic.main.activity_add_book.*

class AddBook : AppCompatActivity() {
    private var db: FirebaseFirestore? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_book)
        db = Firebase.firestore
        val id = System.currentTimeMillis()

        back.setOnClickListener {
            val i =Intent(this,Librarybook::class.java)
            startActivity(i)
        }

        button.setOnClickListener {
            addBook(
                id.toString(),
                bookName.text.toString(),
                bookAouthor.text.toString(),
                bookprice.text.toString(),
                bookluch.text.toString()
            )
            bookName.text.clear()
            bookAouthor.text.clear()
            bookprice.text.clear()
            bookluch.text.clear()
        }
    }
    private fun addBook(id:String,name: String, author: String, price: String, Lunch: String) {
        val books = hashMapOf(
            "id" to id,
            "BookAuthor" to author,
            "BookName" to name,
            "LaunchYear" to Lunch,
            "Price" to price
        )
        db!!.collection("MyLibrary").add(books)

    }
}
